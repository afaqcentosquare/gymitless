
<?php $__env->startSection("title"); ?>
<title>Gymitless | Insert Lead</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!--begin::Content-->
<div class="content d-flex flex-column flex-column-fluid" id="kt_content">
    <!--begin::Subheader-->
    <div class="subheader py-2 py-lg-6 subheader-transparent" id="kt_subheader">
        <div class="container d-flex align-items-center justify-content-between flex-wrap flex-sm-nowrap">
            <!--begin::Details-->
            <div class="d-flex align-items-center flex-wrap mr-2">
                <!--begin::Title-->
                <h5 class="text-dark font-weight-bold mt-2 mb-2 mr-5">New Lead</h5>
                <!--end::Title-->
                <!--begin::Separator-->
                <div class="subheader-separator subheader-separator-ver mt-2 mb-2 mr-5 bg-gray-300"></div>
                <!--end::Separator-->
            </div>
            <!--end::Details-->
        </div>
    </div>
    <!--end::Subheader-->
    <!--begin::Entry-->
    <div class="d-flex flex-column-fluid">
        <!--begin::Container-->
        <div class="container">
            <!--begin::Card-->
            <div class="card card-custom card-transparent">
                <div class="card-body p-0">
                    <!--begin::Wizard-->
                    <div class="wizard wizard-4" id="kt_wizard" data-wizard-state="step-first" data-wizard-clickable="false">
                        <!--begin::Wizard Nav-->

                        <!--end::Wizard Nav-->
                        <!--begin::Card-->
                        <div class="card card-custom card-shadowless rounded-top-0">
                            <!--begin::Body-->
                            <div class="card-body p-0">
                                <div class="row justify-content-center py-8 px-8 py-lg-15 px-lg-10">
                                    <div class="col-xl-12 col-xxl-10">
                                        <!--begin::Wizard Form-->
                                        <form class="form" method="post" action="<?php echo e(route('admin.leads.store')); ?>">
                                            <?php echo csrf_field(); ?>
                                            <div class="row justify-content-center">
                                                <div class="col-xl-9">
                                                    <!--begin::Wizard Step 1-->
                                                    <div class="my-5 step" data-wizard-type="step-content" data-wizard-state="current">
                                                        <h5 class="text-dark font-weight-bold mb-10">Lead Details:</h5>
                                                        <!--begin::Group-->
                                                        <!--end::Group-->
                                                        <!--begin::Group-->
                                                        <div class="form-group row">
                                                            <label class="col-xl-3 col-lg-3 col-form-label">Company Name <span class="required">*</span></label>
                                                            <div class="col-lg-9 col-xl-9">
                                                                <input class="form-control form-control-solid form-control-lg" name="company_name" type="text"  placeholder="Company Name" value="<?php echo e(old('company_name')); ?>"  />
                                                                <?php if($errors->has('company_name')): ?>
                                                                <span class="form-text"><?php echo e($errors->first('company_name')); ?></span>
                                                                <?php endif; ?>
                                                            </div>
                                                            
                                                        </div>
                                                        <!--end::Group-->
                                                        <!--begin::Group-->
                                                        <div class="form-group row">
                                                            <label class="col-xl-3 col-lg-3 col-form-label">Contact <span class="required">*</span></label>
                                                            <div class="col-lg-9 col-xl-9">
                                                                <input class="form-control form-control-solid form-control-lg" name="contact" type="text" placeholder="Contact" value="<?php echo e(old('contact')); ?>"/>
                                                                <?php if($errors->has('contact')): ?>
                                                                <span class="form-text"><?php echo e($errors->first('contact')); ?></span>
                                                                <?php endif; ?>
                                                            </div>
                                                        </div>
                                                        <!--end::Group-->
                                                        <!--begin::Group-->
                                                        <div class="form-group row">
                                                            <label class="col-xl-3 col-lg-3 col-form-label">Phone Number <span class="required">*</span></label>
                                                            <div class="col-lg-9 col-xl-9">
                                                                <input class="form-control form-control-solid form-control-lg" name="number" id="userNumber"  onkeypress="return numberPressed(event);" value="<?php echo e(old('number')); ?>" placeholder="(123) 123 - 1234" type="text" />
                                                                <?php if($errors->has('number')): ?>
                                                                <span class="form-text"><?php echo e($errors->first('number')); ?></span>
                                                                <?php endif; ?>
                                                            </div>
                                                        </div>
                                                        <!--end::Group-->
                                                        <!--begin::Group-->
                                                        <div class="form-group row">
                                                            <label class="col-xl-3 col-lg-3 col-form-label">Email Address<span class="required">*</span></label>
                                                            <div class="col-lg-9 col-xl-9">
                                                                <div class="input-group input-group-solid input-group-lg">
                                                                    <div class="input-group-prepend">
                                                                        <span class="input-group-text">
                                                                            <i class="la la-at"></i>
                                                                        </span>
                                                                    </div>
                                                                    <input type="text" class="form-control form-control-solid form-control-lg" name="email" placeholder="Email Address" value="<?php echo e(old('email')); ?>"/>
                                                                    
                                                                </div>
                                                                <?php if($errors->has('email')): ?>
                                                                    <span class="form-text"><?php echo e($errors->first('email')); ?></span>
                                                                    <?php endif; ?>
                                                                <!-- <span class="form-text text-muted">Enter valid US phone number(e.g: 5678967456).</span> -->
                                                            </div>
                                                        </div>
                                                        <!--end::Group-->
                                                        <!--begin::Group-->
                                                        <div class="form-group row">
                                                            <label class="col-xl-3 col-lg-3 col-form-label">Primary Address <span class="required">*</span></label>
                                                            <div class="col-lg-9 col-xl-9">
                                                                <div class="input-group input-group-solid input-group-lg">
                                                                    <div class="input-group-prepend">
                                                                        <span class="input-group-text">
                                                                            <i class="la la-home"></i>
                                                                        </span>
                                                                    </div>
                                                                    <input type="text" class="form-control form-control-solid form-control-lg" name="primary_address" placeholder="Primary Address" value="<?php echo e(old('primary_address')); ?>"/>
                                                                    
                                                                </div>
                                                                <?php if($errors->has('primary_address')): ?>
                                                                  <span class="form-text"><?php echo e($errors->first('primary_address')); ?></span>
                                                                <?php endif; ?>
                                                            </div>
                                                        </div>
                                                        <!--end::Group-->
                                                        <!--begin::Group-->
                                                        <div class="form-group row">
                                                            <label class="col-xl-3 col-lg-3 col-form-label">Address Line 1 <span class="required">*</span></label>
                                                            <div class="col-lg-9 col-xl-9">
                                                                <div class="input-group input-group-solid input-group-lg">
                                                                    <input type="text" class="form-control form-control-solid form-control-lg" name="addressline1" placeholder="Address Line 1" value="<?php echo e(old('addressline1')); ?>"/>
                                                                    <div class="input-group-append">
                                                                        <span class="input-group-text">.</span>
                                                                    </div>
                                                                </div>
                                                                <?php if($errors->has('addressline1')): ?>
                                                                <span class="form-text"><?php echo e($errors->first('addressline1')); ?></span>
                                                                <?php endif; ?>
                                                            </div>
                                                        </div>
                                                        <div class="form-group row">
                                                            <label class="col-xl-3 col-lg-3 col-form-label">Address Line 2</label>
                                                            <div class="col-lg-9 col-xl-9">
                                                                <div class="input-group input-group-solid input-group-lg">
                                                                    <input type="text" class="form-control form-control-solid form-control-lg" name="addressline2" placeholder="Address Line 2" value="<?php echo e(old('addressline2')); ?>"/>
                                                                    <div class="input-group-append">
                                                                        <span class="input-group-text">.</span>
                                                                    </div>
                                                                </div>
                                                                <?php if($errors->has('addressline2')): ?>
                                                                <span class="form-text"><?php echo e($errors->first('addressline2')); ?></span>
                                                                <?php endif; ?>
                                                            </div>
                                                        </div>
                                                        <div class="form-group row">
                                                            <label class="col-xl-3 col-lg-3 col-form-label">City <span class="required">*</span></label>
                                                            <div class="col-lg-9 col-xl-9">
                                                                <div class="input-group input-group-solid input-group-lg">
                                                                    <input type="text" class="form-control form-control-solid form-control-lg"  name="city" placeholder="City" value="<?php echo e(old('city')); ?>"/>
                                                                    <div class="input-group-append">
                                                                        <span class="input-group-text">.</span>
                                                                    </div>
                                                                </div>
                                                                <?php if($errors->has('city')): ?>
                                                                <span class="form-text"><?php echo e($errors->first('city')); ?></span>
                                                                <?php endif; ?>
                                                            </div>
                                                        </div>
                                                        <div class="form-group row">
                                                            <label class="col-xl-3 col-lg-3 col-form-label">State <span class="required">*</span></label>
                                                            <div class="col-lg-9 col-xl-9">
                                                                <!-- <div class="input-group input-group-solid input-group-lg">
                                                                    <input type="text" class="form-control form-control-solid form-control-lg" required="" name="state" placeholder="State" />
                                                                </div> -->
                                                                <div class="dropdown bootstrap-select form-control">
                                                                    <select class="form-control selectpicker" name="state" data-size="4" tabindex="null">
                                                                        <option value="Alabama" <?php if(old('state') == "Alabama"): ?> <?php echo e('selected'); ?> <?php endif; ?>>Alabama</option>
                                                                        <option value="Alaska" <?php if(old('state') == "Alaska"): ?> <?php echo e('selected'); ?> <?php endif; ?>>Alaska</option>
                                                                        <option value="Arizona" <?php if(old('state') == "Arizona"): ?> <?php echo e('selected'); ?> <?php endif; ?>>Arizona</option>
                                                                        <option value="Arkansas" <?php if(old('state') == "Arkansas"): ?> <?php echo e('selected'); ?> <?php endif; ?>>Arkansas</option>
                                                                        <option value="California" <?php if(old('state') == "California"): ?> <?php echo e('selected'); ?> <?php endif; ?>>California</option>
                                                                        <option value="Colorado" <?php if(old('state') == "Colorado"): ?> <?php echo e('selected'); ?> <?php endif; ?>>Colorado</option>
                                                                        <option value="Connecticut" <?php if(old('state') == "Connecticut"): ?> <?php echo e('selected'); ?> <?php endif; ?>>Connecticut</option>
                                                                        <option value="Delaware" <?php if(old('state') == "Delaware"): ?> <?php echo e('selected'); ?> <?php endif; ?>>Delaware</option>
                                                                        <option value="Florida" <?php if(old('state') == "Florida"): ?> <?php echo e('selected'); ?> <?php endif; ?>>Florida</option>
                                                                        <option value="Georgia" <?php if(old('state') == "Georgia"): ?> <?php echo e('selected'); ?> <?php endif; ?>>Georgia</option>
                                                                        <option value="Hawaii" <?php if(old('state') == "Hawaii"): ?> <?php echo e('selected'); ?> <?php endif; ?>>Hawaii</option>
                                                                        <option value="Idaho" <?php if(old('state') == "Idaho"): ?> <?php echo e('selected'); ?> <?php endif; ?>>Idaho</option>
                                                                        <option value="Illinois" <?php if(old('state') == "Illinois"): ?> <?php echo e('selected'); ?> <?php endif; ?>>Illinois</option>
                                                                        <option value="Indiana" <?php if(old('state') == "Indiana"): ?> <?php echo e('selected'); ?> <?php endif; ?>>Indiana</option>
                                                                        <option value="Iowa" <?php if(old('state') == "Iowa"): ?> <?php echo e('selected'); ?> <?php endif; ?>>Iowa</option>
                                                                        <option value="Kansas" <?php if(old('state') == "Kansas"): ?> <?php echo e('selected'); ?> <?php endif; ?>>Kansas</option>
                                                                        <option value="Kentucky" <?php if(old('state') == "Kentucky"): ?> <?php echo e('selected'); ?> <?php endif; ?>>Kentucky</option>
                                                                        <option value="Louisiana" <?php if(old('state') == "Louisiana"): ?> <?php echo e('selected'); ?> <?php endif; ?>>Louisiana</option>
                                                                        <option value="Maine" <?php if(old('state') == "Maine"): ?> <?php echo e('selected'); ?> <?php endif; ?>>Maine</option>
                                                                        <option value="Maryland" <?php if(old('state') == "Maryland"): ?> <?php echo e('selected'); ?> <?php endif; ?>>Maryland</option>
                                                                        <option value="Massachusetts" <?php if(old('state') == "Massachusetts"): ?> <?php echo e('selected'); ?> <?php endif; ?>>Massachusetts</option>
                                                                        <option value="Michigan" <?php if(old('state') == "Michigan"): ?> <?php echo e('selected'); ?> <?php endif; ?>>Michigan</option>
                                                                        <option value="Minnesota" <?php if(old('state') == "Minnesota"): ?> <?php echo e('selected'); ?> <?php endif; ?>>Minnesota</option>
                                                                        <option value="Mississippi" <?php if(old('state') == "Mississippi"): ?> <?php echo e('selected'); ?> <?php endif; ?>>Mississippi</option>
                                                                        <option value="Missouri" <?php if(old('state') == "Missouri"): ?> <?php echo e('selected'); ?> <?php endif; ?>>Missouri</option>
                                                                        <option value="Montana" <?php if(old('state') == "Montana"): ?> <?php echo e('selected'); ?> <?php endif; ?>>Montana</option>
                                                                        <option value="Nebraska" <?php if(old('state') == "Nebraska"): ?> <?php echo e('selected'); ?> <?php endif; ?>>Nebraska</option>
                                                                        <option value="Nevada" <?php if(old('state') == "Nevada"): ?> <?php echo e('selected'); ?> <?php endif; ?>>Nevada</option>
                                                                        <option value="New Hampshire" <?php if(old('state') == "New Hampshire"): ?> <?php echo e('selected'); ?> <?php endif; ?>>New Hampshire</option>
                                                                        <option value="New Jersey" <?php if(old('state') == "New Jersey"): ?> <?php echo e('selected'); ?> <?php endif; ?>>New Jersey</option>
                                                                        <option value="New Mexico" <?php if(old('state') == "New Mexico"): ?> <?php echo e('selected'); ?> <?php endif; ?>>New Mexico</option>
                                                                        <option value="New York" <?php if(old('state') == "New York"): ?> <?php echo e('selected'); ?> <?php endif; ?>>New York</option>
                                                                        <option value="North Carolina" <?php if(old('state') == "North Carolina"): ?> <?php echo e('selected'); ?> <?php endif; ?>>North Carolina</option>
                                                                        <option value="North Dakota" <?php if(old('state') == "North Dakota"): ?> <?php echo e('selected'); ?> <?php endif; ?>>North Dakota</option>
                                                                        <option value="Ohio" <?php if(old('state') == "Ohio"): ?> <?php echo e('selected'); ?> <?php endif; ?>>Ohio</option>
                                                                        <option value="Oklahoma" <?php if(old('state') == "Oklahoma"): ?> <?php echo e('selected'); ?> <?php endif; ?>>Oklahoma</option>
                                                                        <option value="Oregon" <?php if(old('state') == "Oregon"): ?> <?php echo e('selected'); ?> <?php endif; ?>>Oregon</option>
                                                                        <option value="Pennsylvania" <?php if(old('state') == "Pennsylvania"): ?> <?php echo e('selected'); ?> <?php endif; ?>>Pennsylvania</option>
                                                                        <option value="Rhode Island" <?php if(old('state') == "Rhode Island"): ?> <?php echo e('selected'); ?> <?php endif; ?>>Rhode Island</option>
                                                                        <option value="South Carolina" <?php if(old('state') == "South Carolina"): ?> <?php echo e('selected'); ?> <?php endif; ?>>South Carolina</option>
                                                                        <option value="South Dakota" <?php if(old('state') == "South Dakota"): ?> <?php echo e('selected'); ?> <?php endif; ?>>South Dakota</option>
                                                                        <option value="Tennessee" <?php if(old('state') == "Tennessee"): ?> <?php echo e('selected'); ?> <?php endif; ?>>Tennessee</option>
                                                                        <option value="Texas" <?php if(old('state') == "Texas"): ?> <?php echo e('selected'); ?> <?php endif; ?>>Texas</option>
                                                                        <option value="Utah" <?php if(old('state') == "Utah"): ?> <?php echo e('selected'); ?> <?php endif; ?>>Utah</option>
                                                                        <option value="Vermont" <?php if(old('state') == "Vermont"): ?> <?php echo e('selected'); ?> <?php endif; ?>>Vermont</option>
                                                                        <option value="Virginia" <?php if(old('state') == "Virginia"): ?> <?php echo e('selected'); ?> <?php endif; ?>>Virginia</option>
                                                                        <option value="Washington" <?php if(old('state') == "Washington"): ?> <?php echo e('selected'); ?> <?php endif; ?>>Washington</option>
                                                                        <option value="West Virginia" <?php if(old('state') == "West Virginia"): ?> <?php echo e('selected'); ?> <?php endif; ?>>West Virginia</option>
                                                                        <option value="Wisconsin" <?php if(old('state') == "Wisconsin"): ?> <?php echo e('selected'); ?> <?php endif; ?>>Wisconsin</option>
                                                                        <option value="Wyoming" <?php if(old('state') == "Wyoming"): ?> <?php echo e('selected'); ?> <?php endif; ?>>Wyoming</option>
                                                                    </select>
                                                                </div>
                                                                <?php if($errors->has('state')): ?>
                                                                <span class="form-text"><?php echo e($errors->first('state')); ?></span>
                                                                <?php endif; ?>
                                                            </div>
                                                        </div>
                                                        <div class="form-group row">
                                                            <label class="col-xl-3 col-lg-3 col-form-label">Zip Code <span class="required">*</span></label>
                                                            <div class="col-lg-9 col-xl-9">
                                                                <div class="input-group input-group-solid input-group-lg">
                                                                    <input type="text" class="form-control form-control-solid form-control-lg" name="zip_code" placeholder="Zip Code" maxlength="5" value="<?php echo e(old('zip_code')); ?>"/>
                                                                    <div class="input-group-append">
                                                                        <span class="input-group-text">.</span>
                                                                    </div>
                                                                </div>
                                                                <?php if($errors->has('zip_code')): ?>
                                                                <span class="form-text"><?php echo e($errors->first('zip_code')); ?></span>
                                                                <?php endif; ?>
                                                            </div>
                                                        </div>
                                                        <!--end::Group-->
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="pull-right" style="float: right;">
                                                <input type="submit" class="btn btn-primary" value="submit">
                                            </div>
                                        </form>
                                        <!--end::Wizard Form-->
                                    </div>
                                </div>
                            </div>
                            <!--end::Body-->
                        </div>
                        <!--end::Card-->
                    </div>
                    <!--end::Wizard-->
                </div>
            </div>
            <!--end::Card-->
        </div>
        <!--end::Container-->
    </div>
    <!--end::Entry-->
</div>
<!--end::Content-->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('bottom_links'); ?>

	<!-- phone number format -->
	<script>
		// Format the phone number as the user types it
		document.getElementById('phoneNumber').addEventListener('keyup', function(evt) {
			var phoneNumber = document.getElementById('phoneNumber');
			var charCode = (evt.which) ? evt.which : evt.keyCode;
			phoneNumber.value = phoneFormat(phoneNumber.value);
		});

		// We need to manually format the phone number on page load
		document.getElementById('phoneNumber').value = phoneFormat(document.getElementById('phoneNumber').value);

		// A function to determine if the pressed key is an integer
		function numberPressed(evt) {
			var charCode = (evt.which) ? evt.which : evt.keyCode;
			if (charCode > 31 && (charCode < 48 || charCode > 57) && (charCode < 36 || charCode > 40)) {
				return false;
			}
			return true;
		}

		// A function to format text to look like a phone number
		function phoneFormat(input) {
			// Strip all characters from the input except digits
			input = input.replace(/\D/g, '');

			// Trim the remaining input to ten characters, to preserve phone number format
			input = input.substring(0, 10);

			// Based upon the length of the string, we add formatting as necessary
			var size = input.length;
			if (size == 0) {
				input = input;
			} else if (size < 4) {
				input = '(' + input;
			} else if (size < 7) {
				input = '(' + input.substring(0, 3) + ') ' + input.substring(3, 6);
			} else {
				input = '(' + input.substring(0, 3) + ') ' + input.substring(3, 6) + ' - ' + input.substring(6, 10);
			}
			return input;
		}
	</script>
<!--begin::Page Vendors(used by this page)-->
<script src="<?php echo e(asset('assets/plugins/custom/datatables/datatables.bundle.js')); ?>"></script>
<!--end::Page Vendors-->
<!--begin::Page Scripts(used by this page)-->
<script src="<?php echo e(asset('assets/js/pages/features/datatables/basic/scrollable.js')); ?>"></script>

<script src="<?php echo e(asset('assets/backend/js/pages/features/ktdatatable/base/html-table.js')); ?>"></script>
<!--end::Page Scripts-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gymitless_laravel\resources\views/admin/leads/add.blade.php ENDPATH**/ ?>