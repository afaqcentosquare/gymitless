<footer class="footer-demo section-dark">
    <div class="container">
        <!-- <nav class="pull-left">
                <ul>

                    <li>
                        <a href="http://www.creative-tim.com">
                            Creative Tim
                        </a>
                    </li>
                    <li>
                        <a href="http://blog.creative-tim.com">
                            Blog
                        </a>
                    </li>
                    <li>
                        <a href="http://www.creative-tim.com/product/rubik">
                            Licenses
                        </a>
                    </li>
                </ul>
            </nav> -->
        <div class="copyright">
            &copy; 2020 Gymitless LLC. | Nationwide Access to Fitness Facilities | Sioux Falls, SD | (605) 743-0288
        </div>
    </div>
</footer>






<!--Load the API from the specified URL
    * The async attribute allows the browser to render the page while the API loads
    * The key parameter will contain your own API key (which is not needed for this tutorial)
    * The callback parameter executes the initMap() function
    -->

</body>
<script type="text/javascript">


    var customers = <?php print_r(json_encode($customers)) ?>;


    var mymap = new GMaps({
      el: '#mymap',
      lat: 9.0283719,
      lng: 10.8124002,
      zoom:2
    });


    $.each( customers, function( index, value ){
        $.each( value.locations, function( location_index, location_data ){
            mymap.addMarker({
            lat: location_data.latitude,
            lng: location_data.longitude,
            // title: value.city,
            // click: function(e) {
            //     alert('This is '+value.city+', gujarat from India.');
            // }
            });
            console.log("latitude"+location_data.latitude);
            console.log("longitude"+location_data.latitude);
        });
        
   });


  </script>

<script src="<?php echo e(asset('assets/frontend/js/jquery-1.10.2.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('assets/frontend/js/jquery-ui-1.10.4.custom.min.js')); ?>" type="text/javascript"></script>
<!--  Plugins -->
<script src="<?php echo e(asset('assets/frontend/js/ct-paper-checkbox.js')); ?>"></script>
<script src="<?php echo e(asset('assets/frontend/js/ct-paper-radio.js')); ?>"></script>
<script src="<?php echo e(asset('assets/frontend/js/bootstrap-select.js')); ?>"></script>
<script src="<?php echo e(asset('assets/frontend/js/bootstrap-datepicker.js')); ?>"></script>

<script src="<?php echo e(asset('assets/frontend/js/ct-paper.js')); ?>"></script>

</html><?php /**PATH C:\xampp\htdocs\gymitless_laravel\resources\views/user/footer.blade.php ENDPATH**/ ?>