
<?php $__env->startSection("title"); ?>
<title>Gymitless | Add Customer</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!--begin::Content-->
<div class="content d-flex flex-column flex-column-fluid" id="kt_content">
	<!--begin::Subheader-->
	<div class="subheader py-2 py-lg-6 subheader-transparent" id="kt_subheader">
		<div class="container d-flex align-items-center justify-content-between flex-wrap flex-sm-nowrap">
			<!--begin::Details-->
			<div class="d-flex align-items-center flex-wrap mr-2">
				<!--begin::Title-->
				<h5 class="text-dark font-weight-bold mt-2 mb-2 mr-5">Add Customer</h5>
				<!--end::Title-->
				<!--begin::Separator-->
				<div class="subheader-separator subheader-separator-ver mt-2 mb-2 mr-5 bg-gray-300"></div>
				<!--end::Separator-->
				<!--begin::Search Form-->
				<div class="d-flex align-items-center" id="kt_subheader_search">
					<span class="text-dark-50 font-weight-bold" id="kt_subheader_total">Enter customer details and submit</span>
				</div>
				<!--end::Search Form-->
			</div>
			<!--end::Details-->
			<!--end::Toolbar-->
		</div>
	</div>
	<!--end::Subheader-->
	<!--begin::Entry-->
	<div class="d-flex flex-column-fluid">
		<!--begin::Container-->
		<div class="container">
				<div class="alert alert-success">
					<a href="#" class="close" data-dismiss="alert">&times;</a>
				</div>
				<div class="alert alert-danger">
					<a href="#" class="close" data-dismiss="alert">&times;</a>
				
				</div>
			<!--begin::Card-->
			<div class="card card-custom card-transparent">
				<div class="card-body p-0">
					<!--begin::Card-->
					<div class="card card-custom card-shadowless rounded-top-0">
						<!--begin::Body-->
						<div class="card-body p-0">
							<div class="col-xl-12 col-xxl-10">
								<!--begin::Wizard Form-->
								<form class="form" method="post" action="<?php echo e(route('admin.customer.store')); ?>">
									<?php echo csrf_field(); ?>
									<div class="card-body mt-5">
										<div class="form-group row">
											
											<div class="col-lg-4">
												<label>Company Name <span class="required">*</span></label>
												<input type="text" name="company_name" class="form-control" placeholder="Please enter your company name" value="<?php echo e(old('company_name')); ?>" />
												<?php if($errors->has('company_name')): ?>
                                                    <span class="form-text"><?php echo e($errors->first('company_name')); ?></span>
                                                <?php endif; ?>
											</div>
											<div class="col-lg-4">
												<label>Email <span class="required">*</span></label>
												<input type="text" name="email" class="form-control" placeholder="Please enter your email" value="<?php echo e(old('email')); ?>" />
												<?php if($errors->has('email')): ?>
                                                    <span class="form-text"><?php echo e($errors->first('email')); ?></span>
                                                <?php endif; ?>
											</div>
											<div class="col-lg-4">
												<label>Password <span class="required">*</span></label>
												<input type="password" name="password" class="form-control" placeholder="Please enter your Password" value="<?php echo e(old('password')); ?>" />
												<?php if($errors->has('password')): ?>
                                                    <span class="form-text"><?php echo e($errors->first('password')); ?></span>
                                                <?php endif; ?>
											</div>
										</div>
										<div class="form-group row">
											<div class="col-lg-4">
												<label>Zip Code: <span class="required">*</span></label>
												<input type="text" name="zip_code" value="<?php echo e(old('zip_code')); ?>" id="kt_maxlength_1" maxlength="5" class="form-control" placeholder="Please enter your Zip Code" />
												<?php if($errors->has('zip_code')): ?>
                                                    <span class="form-text"><?php echo e($errors->first('zip_code')); ?></span>
                                                <?php endif; ?>
											</div>
											<div class="col-lg-4">
												<label>Location Name: <span class="required">*</span></label>
												<input type="text" name="location_name" value="<?php echo e(old('location_name')); ?>" class="form-control" placeholder="Please enter your Location name" />
												<?php if($errors->has('location_name')): ?>
                                                    <span class="form-text"><?php echo e($errors->first('location_name')); ?></span>
                                                <?php endif; ?>
											</div>
                                            <div class="form-group" id="lat_area">
                                                <label for="latitude"> Latitude </label>
                                                <input type="text" name="latitude" id="latitude" class="form-control">
                                            </div>
                    
                                            <div class="form-group" id="long_area">
                                                <label for="latitude"> Longitude </label>
                                                <input type="text" name="longitude" id="longitude" class="form-control">
                                            </div>
											<div class="col-lg-4">
												<label>Contact: <span class="required">*</span></label>
												<input type="text" class="form-control" name="contact" value="<?php echo e(old('contact')); ?>" placeholder="Enter your Contact Name" />
												<?php if($errors->has('contact')): ?>
                                                    <span class="form-text"><?php echo e($errors->first('contact')); ?></span>
                                                <?php endif; ?>
											</div>
										</div>
										<div class="form-group row">
											<div class="col-lg-4">
												<label>Number: <span class="required">*</span></label>
												<input type="text" name="number" value="<?php echo e(old('number')); ?>" class="form-control"  id="userNumber" onkeypress="return numberPressed(event);" placeholder="(123) 123 - 1234" />
												<?php if($errors->has('number')): ?>
                                                    <span class="form-text"><?php echo e($errors->first('number')); ?></span>
                                                <?php endif; ?>
											</div>
											<div class="col-lg-4">
												<label>Address Line 1: <span class="required">*</span></label>
												<input type="text" class="form-control" name="addressline1" value="<?php echo e(old('addressline1')); ?>" id="autocomplete" placeholder="Please enter your Address" />
												<?php if($errors->has('addressline1')): ?>
                                                    <span class="form-text"><?php echo e($errors->first('addressline1')); ?></span>
                                                <?php endif; ?>
											</div>
											<div class="col-lg-4">
												<label>Address Line 2:</label>
												<input type="text" class="form-control" name="addressline2" value="<?php echo e(old('addressline2')); ?>" placeholder="Enter your Address" />
												<?php if($errors->has('addressline2')): ?>
                                                    <span class="form-text"><?php echo e($errors->first('addressline2')); ?></span>
                                                <?php endif; ?>
											</div>
										</div>
										<div class="form-group row">
											<div class="col-lg-4">
												<label>City: <span class="required">*</span></label>
												<input type="text" name="city"  value="<?php echo e(old('city')); ?>" class="form-control"  placeholder="Please enter your City name" />
												<?php if($errors->has('city')): ?>
                                                    <span class="form-text"><?php echo e($errors->first('city')); ?></span>
                                                <?php endif; ?>
											</div>
											<div class="col-lg-4">
												<label>State: <span class="required">*</span></label>
												<select name="state" class="form-control">
													<option value="0">Select State</option>
												
													<?php $__currentLoopData = $states; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													<option value="<?php echo e($state->id); ?>" <?php if(old('state') == $state->id): ?> <?php echo e('selected'); ?> <?php endif; ?>><?php echo e($state->state); ?></option>
													<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
														
												</select>
												<?php if($errors->has('state')): ?>
                                                    <span class="form-text"><?php echo e($errors->first('state')); ?></span>
                                                <?php endif; ?>
											</div>
											<div class="col-lg-4">
												<label>Website:</label>
												<input type="text" class="form-control" name="website" value="<?php echo e(old('website')); ?>" placeholder="Enter your Website." />
												<?php if($errors->has('website')): ?>
                                                    <span class="form-text"><?php echo e($errors->first('website')); ?></span>
                                                <?php endif; ?>
											</div>
										</div>
										<div class="form-group row">
											<div class="col-lg-4">
												<label>Day:</label>
												<!-- <input  type="text" class="form-control" name="website" placeholder="Enter your Website." /> -->
												<div class="dropdown bootstrap-select form-control">
													<input type="text" class="form-control" placeholder="abcd" name="monday" value="monday" hidden/>
													<input type="text" class="form-control" placeholder="abcd" value="monday" disabled/>
												</div>
											</div>
											<div class="col-lg-4">
												<label>Staffed hours - Open Time:</label>
												<input type="time" name="monday_opentime" value="<?php echo e(old('monday_opentime')); ?>" class="form-control" placeholder="Please Update your Open timings" />
											</div>
											<div class="col-lg-4">
												<label>Staffed hours - Close Time:</label>
												<input type="time" name="monday_closetime" value="<?php echo e(old('monday_closetime')); ?>" class="form-control" placeholder="Please Update your Close timings" />
											</div>
											
										</div>
										<div class="form-group row">
											<div class="col-lg-4">
												<label>Day:</label>
												<!-- <input  type="text" class="form-control" name="website" placeholder="Enter your Website." /> -->
												<div class="dropdown bootstrap-select form-control">
													<input type="text" class="form-control" placeholder="abcd" name="tuesday" value="tuesday" hidden/>
													<input type="text" class="form-control" placeholder="abcd" value="tuesday" disabled/>
												</div>
											</div>
											<div class="col-lg-4">
												<label>Staffed hours - Open Time:</label>
												<input type="time" name="tuesday_opentime" value="<?php echo e(old('tuesday_opentime')); ?>" class="form-control" placeholder="Please Update your Open timings" />
												<?php if($errors->has('tuesday_opentime')): ?>
                                                    <span class="form-text"><?php echo e($errors->first('tuesday_opentime')); ?></span>
                                                <?php endif; ?>
											</div>
											<div class="col-lg-4">
												<label>Staffed hours - Close Time:</label>
												<input type="time" name="tuesday_closetime" value="<?php echo e(old('tuesday_closetime')); ?>" class="form-control" placeholder="Please Update your Close timings" />
												<?php if($errors->has('tuesday_closetime')): ?>
                                                    <span class="form-text"><?php echo e($errors->first('tuesday_closetime')); ?></span>
                                                <?php endif; ?>
											</div>
											
										</div>
										<div class="form-group row">
											<div class="col-lg-4">
												<label>Day:</label>
												<!-- <input  type="text" class="form-control" name="website" placeholder="Enter your Website." /> -->
												<div class="dropdown bootstrap-select form-control">
													<input type="text" class="form-control" placeholder="abcd" name="wednesday" value="wednesday" hidden/>
													<input type="text" class="form-control" placeholder="abcd"  value="wednesday" disabled/>
												</div>
											</div>
											<div class="col-lg-4">
												<label>Staffed hours - Open Time:</label>
												<input type="time" name="wednesday_opentime" value="<?php echo e(old('wednesday_opentime')); ?>"  class="form-control" placeholder="Please Update your Open timings" />
												<?php if($errors->has('wednesday_opentime')): ?>
                                                    <span class="form-text"><?php echo e($errors->first('wednesday_opentime')); ?></span>
                                                <?php endif; ?>
											</div>
											<div class="col-lg-4">
												<label>Staffed hours - Close Time:</label>
												<input type="time" name="wednesday_closetime" value="<?php echo e(old('wednesday_closetime')); ?>" class="form-control" placeholder="Please Update your Close timings" />
												<?php if($errors->has('wednesday_closetime')): ?>
                                                    <span class="form-text"><?php echo e($errors->first('wednesday_closetime')); ?></span>
                                                <?php endif; ?>
											</div>
											
										</div>
										<div class="form-group row">
											<div class="col-lg-4">
												<label>Day:</label>
												<!-- <input  type="text" class="form-control" name="website" placeholder="Enter your Website." /> -->
												<div class="dropdown bootstrap-select form-control">
													<input type="text" class="form-control" placeholder="abcd" name="thursday" value="thursday" hidden/>
													<input type="text" class="form-control" placeholder="abcd"  value="thursday" disabled/>
												</div>
											</div>
											<div class="col-lg-4">
												<label>Staffed hours - Open Time:</label>
												<input type="time" name="thursday_opentime" value="<?php echo e(old('thursday_opentime')); ?>"  class="form-control" placeholder="Please Update your Open timings" />
												<?php if($errors->has('thursday_opentime')): ?>
                                                    <span class="form-text"><?php echo e($errors->first('thursday_opentime')); ?></span>
                                                <?php endif; ?>
											</div>
											<div class="col-lg-4">
												<label>Staffed hours - Close Time:</label>
												<input type="time" name="thursday_closetime" value="<?php echo e(old('thursday_closetime')); ?>"  class="form-control" placeholder="Please Update your Close timings" />
												<?php if($errors->has('thursday_closetime')): ?>
                                                    <span class="form-text"><?php echo e($errors->first('thursday_closetime')); ?></span>
                                                <?php endif; ?>
											</div>
											
										</div>
										<div class="form-group row">
											<div class="col-lg-4">
												<label>Day:</label>
												<!-- <input  type="text" class="form-control" name="website" placeholder="Enter your Website." /> -->
												<div class="dropdown bootstrap-select form-control">
													<input type="text" class="form-control" placeholder="abcd" name="friday" value="friday" hidden/>
													<input type="text" class="form-control" placeholder="abcd"  value="friday" disabled/>
												</div>
											</div>
											<div class="col-lg-4">
												<label>Staffed hours - Open Time: <span class="required">*</span></label>
												<input type="time" name="friday_opentime" class="form-control" value="<?php echo e(old('friday_opentime')); ?>"  placeholder="Please Update your Open timings" />
												<?php if($errors->has('friday_opentime')): ?>
                                                    <span class="form-text"><?php echo e($errors->first('friday_opentime')); ?></span>
                                                <?php endif; ?>
											</div>
											<div class="col-lg-4">
												<label>Staffed hours - Close Time: <span class="required">*</span></label>
												<input type="time" name="friday_closetime" class="form-control" value="<?php echo e(old('friday_closetime')); ?>"  placeholder="Please Update your Close timings" />
												<?php if($errors->has('friday_closetime')): ?>
                                                    <span class="form-text"><?php echo e($errors->first('friday_closetime')); ?></span>
                                                <?php endif; ?>
											</div>
											
										</div>
										<div class="form-group row">
											<div class="col-lg-4">
												<label>Day:</label>
												<!-- <input  type="text" class="form-control" name="website" placeholder="Enter your Website." /> -->
												<div class="dropdown bootstrap-select form-control">
													<input type="text" class="form-control" placeholder="abcd" name="saturday" value="saturday" hidden/>
													<input type="text" class="form-control" placeholder="abcd"  value="saturday" disabled/>
												</div>
											</div>
											<div class="col-lg-4">
												<label>Staffed hours - Open Time:</label>
												<input type="time" name="saturday_opentime" class="form-control" value="<?php echo e(old('saturday_opentime')); ?>"  placeholder="Please Update your Open timings" />
												<?php if($errors->has('saturday_opentime')): ?>
                                                    <span class="form-text"><?php echo e($errors->first('saturday_opentime')); ?></span>
                                                <?php endif; ?>
											</div>
											<div class="col-lg-4">
												<label>Staffed hours - Close Time:</label>
												<input type="time" name="saturday_closetime" class="form-control" value="<?php echo e(old('saturday_closetime')); ?>"  placeholder="Please Update your Close timings" />
												<?php if($errors->has('saturday_closetime')): ?>
                                                    <span class="form-text"><?php echo e($errors->first('saturday_closetime')); ?></span>
                                                <?php endif; ?>
											</div>
											
										</div>
										<div class="form-group row">
											<div class="col-lg-4">
												<label>Day:</label>
												<!-- <input  type="text" class="form-control" name="website" placeholder="Enter your Website." /> -->
												<div class="dropdown bootstrap-select form-control">
													<input type="text" class="form-control" placeholder="abcd" name="sunday" value="sunday" hidden/>
													<input type="text" class="form-control" placeholder="abcd"  value="sunday" disabled/>
												</div>
											</div>
											<div class="col-lg-4">
												<label>Staffed hours - Open Time:</label>
												<input type="time" name="sunday_opentime" class="form-control" value="<?php echo e(old('sunday_opentime')); ?>"  placeholder="Please Update your Open timings" />
												<?php if($errors->has('sunday_opentime')): ?>
                                                    <span class="form-text"><?php echo e($errors->first('sunday_opentime')); ?></span>
                                                <?php endif; ?>
											</div>
											<div class="col-lg-4">
												<label>Staffed hours - Close Time:</label>
												<input type="time" name="sunday_closetime" class="form-control" value="<?php echo e(old('sunday_closetime')); ?>" placeholder="Please Update your Close timings" />
												<?php if($errors->has('sunday_closetime')): ?>
                                                    <span class="form-text"><?php echo e($errors->first('sunday_closetime')); ?></span>
                                                <?php endif; ?>
											</div>
											
										</div>
										
										<div class="form-group row">
											<div class="col-lg-12">
												<label>Mailing Address: <span class="required">*</span></label>
												<div class="checkbox-inline">
													<label class="checkbox checkbox-outline checkbox-outline-2x checkbox-primary mb-2">
														<input type="checkbox" id="mailingAddressCheckbox" name="is_same_physical_address" checked="checked">
														<span></span>
														Mailing address same as physical address.
													</label>
												</div>
												<!-- IF NOT -->
												<label>If not, then fill out the details please: <span class="required">*</span></label>
												<hr>
											</div>
										</div>
										<div class="mailing_address_div" style="display: none;">
											<div class="form-group row">
												<div class="col-lg-6">
													<label>Address Line 1:</label>
													<input type="text" name="mailing_addressline1" value="<?php echo e(old('mailing_addressline1')); ?>" class="form-control disable" placeholder="Please enter your Address Line 1." />
													<?php if($errors->has('mailing_addressline1')): ?>
                                                    <span class="form-text"><?php echo e($errors->first('mailing_addressline1')); ?></span>
                                                	<?php endif; ?>
												</div>
												<div class="col-lg-6">
													<label>Address Line 2:</label>
													<input type="text" name="mailing_addressline2" value="<?php echo e(old('mailing_addressline2')); ?>" class="form-control disable" placeholder="Please enter your Address Line 2." />
													<?php if($errors->has('mailing_addressline2')): ?>
                                                    <span class="form-text"><?php echo e($errors->first('mailing_addressline2')); ?></span>
                                                	<?php endif; ?>
												</div>
											</div>
											<div class="form-group row">
												<div class="col-lg-4">
													<label>City:</label>
													<input type="text" name="mailing_city" value="<?php echo e(old('mailing_city')); ?>" class="form-control disable" placeholder="Please enter your City." />
													<?php if($errors->has('mailing_city')): ?>
                                                    <span class="form-text"><?php echo e($errors->first('mailing_city')); ?></span>
                                                	<?php endif; ?>
												</div>
												<div class="col-lg-4">
													<label>State:</label>
													<select name="mailing_state" class="form-control">
														<option value="0">Select State</option>
														
														<?php $__currentLoopData = $states; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
														<option value="<?php echo e($state->id); ?>" <?php if(old('mailing_state') == $state->id): ?> <?php echo e('selected'); ?> <?php endif; ?>><?php echo e($state->state); ?></option>
														<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
														
													</select>
													<?php if($errors->has('mailing_state')): ?>
                                                    <span class="form-text"><?php echo e($errors->first('mailing_state')); ?></span>
                                                	<?php endif; ?>
												</div>
												<div class="col-lg-4">
													<label>Zip Code:</label>
													<input type="text" name="mailing_zip_code" value="<?php echo e(old('mailing_zip_code')); ?>" class="form-control disable" maxlength="5" placeholder="Please enter yourZip Code." />
													<?php if($errors->has('mailing_zip_code')): ?>
                                                    <span class="form-text"><?php echo e($errors->first('mailing_zip_code')); ?></span>
                                                	<?php endif; ?>
												</div>
											</div>
											<hr>
										</div>

										<div class="form-group row">
											<div class="col-lg-4">
												<label>Payment Method: <span class="required">*</span></label>
												<div class="dropdown bootstrap-select form-control">
													<select class="form-control selectpicker" name="payment_method" data-size="4" tabindex="null" id="payment_method">
														<option value="select_payment_method">Select Payment Method</option>
														<option value="bank_account" <?php if(old('select_payment_method') == "bank_account"): ?> <?php echo e('selected'); ?> <?php endif; ?>>Bank Account</option>
														<option value="credit_card" <?php if(old('select_payment_method') == "credit_card"): ?> <?php echo e('selected'); ?> <?php endif; ?>>Credit Card</option>
													</select>
													<?php if($errors->has('payment_method')): ?>
                                                    <span class="form-text"><?php echo e($errors->first('payment_method')); ?></span>
                                                	<?php endif; ?>
												</div>
											</div>
										</div>
										<div class="form-group row bank_account" style="display: none;">
											<div class="col-lg-4">
												<label>Routing Number: <span class="required">*</span></label>
												<input type="number" name="bank_routing_number" value="<?php echo e(old('bank_routing_number')); ?>" class="form-control" id="kt_maxlength_1" maxlength="9" placeholder="Please enter your Routing Number" />
												<?php if($errors->has('bank_routing_number')): ?>
                                                    <span class="form-text"><?php echo e($errors->first('bank_routing_number')); ?></span>
                                                <?php endif; ?>
											</div>
											<div class="col-lg-4">
												<label>Account Number: <span class="required">*</span></label>
												<input type="number" name="bank_account_number" value="<?php echo e(old('bank_account_number')); ?>" class="form-control" placeholder="Please enter your Account Number" />
												<?php if($errors->has('bank_account_number')): ?>
                                                    <span class="form-text"><?php echo e($errors->first('bank_account_number')); ?></span>
                                                <?php endif; ?>
											</div>
										</div>

										<div class="form-group row credit_card" style="display: none;">
											<div class="col-lg-4">
												<label>Card Type: <span class="required">*</span></label>
												<div class="dropdown bootstrap-select form-control">
													<select class="form-control selectpicker" name="card_type" onchange="changeValue(this);" data-size="4" tabindex="null">
														<option value="VISA" <?php if(old('card_type') == "VISA"): ?> <?php echo e('selected'); ?> <?php endif; ?>>VISA</option>
														<option value="MAST" <?php if(old('card_type') == "MAST"): ?> <?php echo e('selected'); ?> <?php endif; ?>>Mastercard</option>
														<option value="AMEX" <?php if(old('card_type') == "AMEX"): ?> <?php echo e('selected'); ?> <?php endif; ?>>American Express</option>
														<option value="DISC" <?php if(old('card_type') == "DISC"): ?> <?php echo e('selected'); ?> <?php endif; ?>>Discover</option>
													</select>
													<?php if($errors->has('card_type')): ?>
                                                    <span class="form-text"><?php echo e($errors->first('card_type')); ?></span>
                                                	<?php endif; ?>
												</div>
											</div>
											<div class="col-lg-4">
												<label>Card Number: <span class="required">*</span></label>
												<div class="dropdown bootstrap-select form-control">
													<input type="text" name="card_number" id="card_number" value="<?php echo e(old('card_number')); ?>" id="kt_maxlength_1" maxlength="16" class="form-control" placeholder="Please enter your Card Number" />
													<?php if($errors->has('card_number')): ?>
                                                    <span class="form-text"><?php echo e($errors->first('card_number')); ?></span>
                                                	<?php endif; ?>
												</div>
											</div>
											<div class="col-lg-4">
												<label>Expiration Month: <span class="required">*</span></label>
												<div class="dropdown bootstrap-select form-control">
													<input type="text" name="card_expiration_month" value="<?php echo e(old('card_expiration_month')); ?>" id="kt_maxlength_1" maxlength="2" class="form-control" placeholder="Please enter your Expiration Month" />
													<?php if($errors->has('card_expiration_month')): ?>
                                                    <span class="form-text"><?php echo e($errors->first('card_expiration_month')); ?></span>
                                                	<?php endif; ?>
												</div>
											</div>
										</div>

										<div class="form-group row credit_card" style="display: none;">
											<div class="col-lg-4">
												<label>Expiration Year: <span class="required">*</span></label>
												<div class="dropdown bootstrap-select form-control">
													<input type="text" name="card_expiration_year" value="<?php echo e(old('card_expiration_year')); ?>" id="kt_maxlength_1" maxlength="4" class="form-control" placeholder="Please enter your Expiration Year" />
													<?php if($errors->has('card_expiration_year')): ?>
                                                    <span class="form-text"><?php echo e($errors->first('card_expiration_year')); ?></span>
                                                	<?php endif; ?>
												</div>
											</div>
											<div class="col-lg-4">
												<label>CVV: <span class="required">*</span></label>
												<div class="dropdown bootstrap-select form-control">
													<input type="text" name="card_cvv" value="<?php echo e(old('card_cvv')); ?>" id="cvv" id="kt_maxlength_1" maxlength="4" class="form-control" placeholder="Please enter your CVV" />
													<?php if($errors->has('card_cvv')): ?>
                                                    <span class="form-text"><?php echo e($errors->first('card_cvv')); ?></span>
                                                	<?php endif; ?>
												</div>
											</div>
										</div>
										<hr>

										<!-- Explanation of Recurring Charges -->
										<div class="form-group row">
											<div class="col-lg-12">
												<h5 class="text-dark font-weight-bold mt-2 mb-2 mr-5">Explanation of Recurring Charges</h5>
												<br>
											</div>
											<div class="col-lg-4">
												<label># of Locations:</label>
												<div class="dropdown bootstrap-select form-control">
													<input type="text" disabled="disabled" name="no_Of_Locations" id="no_Of_Locations" class="form-control" value="">
												</div>
											</div>
											<div class="col-lg-4">
												<label>Monthly RC Subtotal:</label>
												<div class="dropdown bootstrap-select form-control">
													<input type="text" disabled="disabled" name="monthly_rc_subtotal" id="monthly_rc_subtotal" class="form-control" value="">
												</div>
											</div>
											<div class="col-lg-4">
												<label>Processing Fee:</label>
												<div class="dropdown bootstrap-select form-control">
													<input type="text" disabled="disabled" name="Processing_Fee" id="Processing_Fee" class="form-control" value="">
												</div>
											</div>
											<div class="col-lg-4">
												<label>Taxes:</label>
												<div class="dropdown bootstrap-select form-control">
													<input type="text" disabled="disabled" name="taxes_of_state" id="taxes_of_state" class="form-control" value="">
												</div>
											</div>
											<div class="col-lg-4">
												<label>Total Monthly RC:</label>
												<div class="dropdown bootstrap-select form-control">
													<input type="text" disabled="disabled" name="total_monthly_rc" id="total_monthly_rc" class="form-control" value="">
												</div>
											</div>
										</div>

										<!-- Explanation of One Time Charges  -->
										<div class="form-group row">
											<div class="col-lg-12">
												<h5 class="text-dark font-weight-bold mt-2 mb-2 mr-5">Explanation of One Time Charges</h5>
												<br>
											</div>
											<div class="col-lg-4">
												<label># of Locations:</label>
												<div class="dropdown bootstrap-select form-control">
													<input type="text" disabled="disabled" name="no_Of_Locations" id="no_Of_Locations" class="form-control" value="">
												</div>
											</div>
											<div class="col-lg-4">
												<label>One Time Charges Subtotal:</label>
												<div class="dropdown bootstrap-select form-control">
													<input type="text" disabled="disabled" name="One_Time_Charges_Subtotal" id="One_Time_Charges_Subtotal" class="form-control" value="">
												</div>
											</div>
											<div class="col-lg-4">
												<label>Processing Fee:</label>
												<div class="dropdown bootstrap-select form-control">
													<input type="text" disabled="disabled" name="Processing_Fee" id="Processing_Fee" class="form-control" value="">
												</div>
											</div>
											<div class="col-lg-4">
												<label>Taxes:</label>
												<div class="dropdown bootstrap-select form-control">
													<input type="text" disabled="disabled" name="taxes_of_state" id="taxes_of_state" class="form-control" value="">
												</div>
											</div>
											<div class="col-lg-4">
												<label>Total One Time Charges:</label>
												<div class="dropdown bootstrap-select form-control">
													<input type="text" disabled="disabled" name="Total_One_Time_Charges" id="Total_One_Time_Charges" class="form-control" value="">
												</div>
											</div>
										</div>


									</div>

									<!-- footer START -->
									<div class="card-footer">
										<div class="row">
											<div class="col-lg-6">
												<button type="submit" class="btn btn-primary mr-2">Save</button>
												<button type="reset" class="btn btn-secondary">Cancel</button>
											</div>
										</div>
									</div>
									<!-- footer END -->
								</form>
								<!--end::Wizard Form-->
							</div>
						</div>
						<!--end::Body-->
					</div>
					<!--end::Card-->
				</div>
			</div>
			<!--end::Card-->
		</div>
		<!--end::Container-->
	</div>
	<!--end::Entry-->
</div>
<!--end::Content-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gymitless_laravel\resources\views/admin/customers/add.blade.php ENDPATH**/ ?>