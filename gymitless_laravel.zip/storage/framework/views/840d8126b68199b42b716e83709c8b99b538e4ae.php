
<?php $__env->startSection("title"); ?>
<title>Gymitless | Edit User</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="content d-flex flex-column flex-column-fluid" id="kt_content">
    <!--begin::Entry-->
    <div class="d-flex flex-column-fluid">
        <!--begin::Container-->
        <div class="container">
            <br>
            <!--begin::Card-->
            <div class="card card-custom gutter-b">
                <?php if(session('success')): ?>
                <div class="p-7">
                    <div class="alert alert-success">
                        <a href="#" class="close" data-dismiss="alert">&times;</a>
                        <?php echo e(session('success')); ?>

                    </div>
                </div>
                <?php endif; ?>
                <?php if(session('error')): ?>
                <div class="p-7">
                    <div class="alert alert-danger">
                        <a href="#" class="close" data-dismiss="alert">&times;</a>
                        <?php echo e(session('error')); ?>

                    </div>
                </div>
                <?php endif; ?>
                <div class="card-header flex-wrap border-0 pt-6 pb-0">
                    <div class="card-title">
                        <h3 class="card-label">Edit User <span class="form-text text-muted">Edit and save your Information.</span>
                        </h3>
                    </div>
                </div>
                <div class="card-body">
                    <form class="form" action="<?php echo e(route('admin.users.update', $user->id)); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="form-group row">
                            <div class="col-lg-4">
                                <label>Name:</label>
                                <input type="text" class="form-control" placeholder="Please enter your name" name="name" value="<?php echo e(old("name",$user->name)); ?>" />
                                <?php if($errors->has('name')): ?>
                                <span class="form-text text-muted"><?php echo e($errors->first('name')); ?></span>
                                <?php endif; ?>
                            </div>
                            <div class="col-lg-4">
                                <label>Email:</label>
                                <div class="input-group">
                                    <input type="email" class="form-control" placeholder="Please enter your Email" name="email" value="<?php echo e(old("email",$user->email)); ?>" />
                                    <div class="input-group-append"><span class="input-group-text"><i class="flaticon-multimedia"></i></span></div>
                                </div>
                                <?php if($errors->has('email')): ?>
                                <span class="form-text text-muted"><?php echo e($errors->first('email')); ?></span>
                                <?php endif; ?>
                            </div>
                            <div class="col-lg-4">
                                <label>Recovery Email:</label>
                                <div class="input-group">
                                    <input type="email" class="form-control" placeholder="Please enter your Recovery Email" name="email_recovery" value="<?php echo e(old("email_recovery",$user->email_recovery)); ?>" />
                                    <div class="input-group-append"><span class="input-group-text"><i class="flaticon-multimedia"></i></span></div>
                                </div>
                                <?php if($errors->has('email_recovery')): ?>
                                <span class="form-text text-muted"><?php echo e($errors->first('email_recovery')); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-lg-3">
                                <label>Phone Number:</label>
                                <div class="input-group">
                                    <input type="text" class="form-control" placeholder="(000) 000-0000" name="number" id="userNumber" onkeypress="return numberPressed(event);" value="<?php echo e(old("number",$user->number)); ?>" />
                                    <div class="input-group-append"><span class="input-group-text"><i class="la la-phone"></i></span></div>
                                </div>
                                <?php if($errors->has('number')): ?>
                                <span class="form-text text-muted"><?php echo e($errors->first('number')); ?></span>
                                <?php endif; ?>
                            </div>
                            <div class="col-lg-1">
                                <label>Ext. :</label>
                                <div class="input-group">
                                    <input type="number" class="form-control" name="ext_number" value="<?php echo e(old("ext_number",$user->ext_number)); ?>"/>
                                </div>
                                <?php if($errors->has('ext_number')): ?>
                                <span class="form-text text-muted"><?php echo e($errors->first('ext_number')); ?></span>
                                <?php endif; ?>
                            </div>
                            <div class="col-lg-4">
                                <label>Address Line 1:</label>
                                <div class="input-group">
                                    <input type="text" class="form-control" placeholder="Enter your address line 1" name="addressline1" value="<?php echo e(old("addressline1",$user->addressline1)); ?>" />
                                    <div class="input-group-append"></div>
                                </div>
                                <?php if($errors->has('addressline1')): ?>
                                <span class="form-text text-muted"><?php echo e($errors->first('addressline1')); ?></span>
                                <?php endif; ?>
                            </div>
                            <div class="col-lg-4">
                                <label>Address Line 2:</label>
                                <div class="input-group">
                                    <input type="text" class="form-control" placeholder="Enter your address line 2" name="addressline2" value="<?php echo e(old("addressline2",$user->addressline2)); ?>" />
                                    <div class="input-group-append"></div>
                                </div>
                                <?php if($errors->has('addressline2')): ?>
                                <span class="form-text text-muted"><?php echo e($errors->first('addressline2')); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-lg-4">
                                <label>City:</label>
                                <div class="input-group">
                                    <input type="text" class="form-control" placeholder="Enter your city" name="city" value="<?php echo e(old("city",$user->city)); ?>" />
                                    <div class="input-group-append"></div>
                                </div>
                                <?php if($errors->has('city')): ?>
                                <span class="form-text text-muted"><?php echo e($errors->first('city')); ?></span>
                                <?php endif; ?>
                            </div>
                            <div class="col-lg-4">
                                <label>State:</label>
                                <div class="input-group">
                                    <input type="text" class="form-control" placeholder="Enter your State" name="state" value="<?php echo e(old("state",$user->state)); ?>" />
                                    <div class="input-group-append"></div>
                                </div>
                                <?php if($errors->has('state')): ?>
                                <span class="form-text text-muted"><?php echo e($errors->first('state')); ?></span>
                                <?php endif; ?>
                            </div>
                            <div class="col-lg-4">
                                <label>Zip Code:</label>
                                <div class="input-group">
                                    <input type="number" class="form-control" placeholder="Enter your Zip Code" name="zipcode" value="<?php echo e(old("zipcode",$user->zipcode)); ?>" />
                                    <div class="input-group-append"></div>
                                </div>
                                <?php if($errors->has('zipcode')): ?>
                                <span class="form-text text-muted"><?php echo e($errors->first('zipcode')); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-lg-4">
                                <label>Password:</label>
                                <div class="input-group">
                                    <input type="password" class="form-control" placeholder="Enter your Password" name="password" value="<?php echo e(old("password",$user->password)); ?>" />
                                    <div class="input-group-append"></div>
                                </div>
                                <?php if($errors->has('password')): ?>
                                <span class="form-text text-muted"><?php echo e($errors->first('password')); ?></span>
                                <?php endif; ?>
                            </div>
                            <div class="col-lg-4">
                                <label>User Group:</label>
                                <div class="dropdown bootstrap-select form-control">
                                    <select class="form-control selectpicker" data-size="5" tabindex="null" name="user_group">
                                    <option value="super_user" <?php if(old('user_group',$user->user_group) == "super_user"): ?> <?php echo e('selected'); ?> <?php endif; ?>>SuperUser</option>
                                    <option value="administator" <?php if(old('user_group',$user->user_group) == "administator"): ?> <?php echo e('selected'); ?> <?php endif; ?>>Administrator</option>
                                    <option value="account_manager" <?php if(old('user_group',$user->user_group) == "account_manager"): ?> <?php echo e('selected'); ?> <?php endif; ?>>Account Manager</option>
                                    <option value="customer_service" <?php if(old('user_group',$user->user_group) == "customer_service"): ?> <?php echo e('selected'); ?> <?php endif; ?>>Customer Service</option>
                                    <option value="technical_support" <?php if(old('user_group',$user->user_group) == "technical_support"): ?> <?php echo e('selected'); ?> <?php endif; ?>>Technical Support</option>
                                    </select>
                                </div>
                                <?php if($errors->has('user_group')): ?>
                                <span class="form-text text-muted"><?php echo e($errors->first('user_group')); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-form-label col-4">Photo</label>
                            <div class="col-12">
                                <div class="image-input image-input-empty image-input-outline" id="kt_user_edit_avatar" style="background-image: url(<?php echo e(asset($user->profile_avatar)); ?>)">
                                    <div class="image-input-wrapper"></div>
                                    <label class="btn btn-xs btn-icon btn-circle btn-white btn-hover-text-primary btn-shadow" data-action="change" data-toggle="tooltip" title="" data-original-title="Change avatar">
                                        <i class="fa fa-pen icon-sm text-muted"></i>
                                        <input type="file" name="profile_avatar" accept=".png, .jpg, .jpeg" />
                                        <input type="hidden" name="profile_avatar_remove" />
                                    </label>
                                    <span class="btn btn-xs btn-icon btn-circle btn-white btn-hover-text-primary btn-shadow" data-action="cancel" data-toggle="tooltip" title="Cancel avatar">
                                        <i class="ki ki-bold-close icon-xs text-muted"></i>
                                    </span>
                                    <span class="btn btn-xs btn-icon btn-circle btn-white btn-hover-text-primary btn-shadow" data-action="remove" data-toggle="tooltip" title="Remove avatar">
                                        <i class="ki ki-bold-close icon-xs text-muted"></i>
                                    </span>
                                </div>
                            </div>
                        </div>
                        <input name="previous_image" value="<?php echo e($user->profile_avatar); ?>" hidden/>
                        <hr>
                        <div class="row">
                            <div class="col-lg-6">
                                <button type="submit" class="btn btn-primary mr-2">Save</button>
                                <button type="reset" class="btn btn-secondary">Cancel</button>
                            </div>
                        </div>
                    </form>
                    <!--end::Card-->
                </div>
                <!--end::Container-->
            </div>
            <!--end::Entry-->
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gymitless_laravel\resources\views/admin/users/edit.blade.php ENDPATH**/ ?>