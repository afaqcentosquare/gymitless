
<?php $__env->startSection("title"); ?>
<title>Gymitless | Home</title>
<?php $__env->stopSection(); ?>


<?php $__env->startSection("content"); ?>
<div class="alert alert-danger landing-alert">
    <div class="container text-center">
        <h3>Find a gym</h3>
    </div>
</div>

<div class="wrapper">
    <div class="landing-header">
        <div id="mymap"></div>
        <!-- <iframe src="https://www.google.com/maps/d/u/0/embed?mid=1ypkIC2fMmJk6Wvfl7EEXLbCUaA_YR4H-" width="100%" height="550"></iframe> -->

        <!-- <div class="container">
            <div class="motto">
                
                <h1 class="title-uppercase">Example page</h1>
                <h3>Start designing your landing page here.</h3>
                <br />
                <a href="https://www.youtube.com/watch?v=dQw4w9WgXcQ" class="btn"><i class="fa fa-play"></i>Watch video</a>
                <a class="btn">Download</a>
            </div>
        </div>     -->
    </div>
    <div class="main">
        <div class="section section-light-brown landing-section">
            <div class="container">
                <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $__currentLoopData = $customer->locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="row">
               
                    <div class="col-md-5 column">
                        <h6><?php echo e($location->location_name); ?></h6>
                        <p><?php echo e($location->addressline1); ?></p>
                        <p><?php echo e($location->city); ?></p>
                        <p><?php echo e($location->zip_code); ?></p>
                        <a class="btn  btn-simple" href="<?php echo e($location->website); ?>"><?php echo e($location->website); ?></a>
                    </div>
                    <div class="col-md-5 column">
                        <h6>Staffed Hours</h6>
                        <?php $__currentLoopData = $location->timings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $timing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p><?php echo e(ucwords($timing->day)." ". $timing->open_time." - ". $timing->close_time); ?></p>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                    </div>
                    <div class="col-md-2 column">
                        <br><br>
                        <a class="btn btn-danger get-directions" href="#">GET DIRECTIONS</a>
                        <p class="btn-direction">(0. 5 Miles)</p>
                    </div>
                   
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gymitless_laravel\resources\views/user/index.blade.php ENDPATH**/ ?>