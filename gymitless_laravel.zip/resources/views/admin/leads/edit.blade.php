@extends('admin.master')
@section("title")
<title>Gymitless | Edit Lead</title>
@endsection
@section('content')
<!--begin::Content-->
<div class="content d-flex flex-column flex-column-fluid" id="kt_content">
    <!--begin::Subheader-->
    <div class="subheader py-2 py-lg-6 subheader-transparent" id="kt_subheader">
        <div class="container d-flex align-items-center justify-content-between flex-wrap flex-sm-nowrap">
            <!--begin::Details-->
            <div class="d-flex align-items-center flex-wrap mr-2">
                <!--begin::Title-->
                <h5 class="text-dark font-weight-bold mt-2 mb-2 mr-5">New Lead</h5>
                <!--end::Title-->
                <!--begin::Separator-->
                <div class="subheader-separator subheader-separator-ver mt-2 mb-2 mr-5 bg-gray-300"></div>
                <!--end::Separator-->
            </div>
            <!--end::Details-->
        </div>
    </div>
    <!--end::Subheader-->
    <!--begin::Entry-->
    <div class="d-flex flex-column-fluid">
        <!--begin::Container-->
        <div class="container">
            <!--begin::Card-->
            <div class="card card-custom card-transparent">
                <div class="card-body p-0">
                    <!--begin::Wizard-->
                    <div class="wizard wizard-4" id="kt_wizard" data-wizard-state="step-first" data-wizard-clickable="false">
                        <!--begin::Wizard Nav-->

                        <!--end::Wizard Nav-->
                        <!--begin::Card-->
                        <div class="card card-custom card-shadowless rounded-top-0">
                            <!--begin::Body-->
                            <div class="card-body p-0">
                                <div class="row justify-content-center py-8 px-8 py-lg-15 px-lg-10">
                                    <div class="col-xl-12 col-xxl-10">
                                        <!--begin::Wizard Form-->
                                        <form class="form" method="post" action="{{route('admin.leads.update', $lead->id)}}">
                                            @csrf
                                            <div class="row justify-content-center">
                                                <div class="col-xl-9">
                                                    <!--begin::Wizard Step 1-->
                                                    <div class="my-5 step" data-wizard-type="step-content" data-wizard-state="current">
                                                        <h5 class="text-dark font-weight-bold mb-10">Lead Details:</h5>
                                                        <!--begin::Group-->
                                                        <!--end::Group-->
                                                        <!--begin::Group-->
                                                        <div class="form-group row">
                                                            <label class="col-xl-3 col-lg-3 col-form-label">Company Name <span class="required">*</span></label>
                                                            <div class="col-lg-9 col-xl-9">
                                                                <input class="form-control form-control-solid form-control-lg" name="company_name" type="text"  placeholder="Company Name" value="{{old('company_name',$lead->company_name)}}"  />
                                                                @if($errors->has('company_name'))
                                                                <span class="form-text">{{ $errors->first('company_name') }}</span>
                                                                @endif
                                                            </div>
                                                            
                                                        </div>
                                                        <!--end::Group-->
                                                        <!--begin::Group-->
                                                        <div class="form-group row">
                                                            <label class="col-xl-3 col-lg-3 col-form-label">Contact <span class="required">*</span></label>
                                                            <div class="col-lg-9 col-xl-9">
                                                                <input class="form-control form-control-solid form-control-lg" name="contact" type="text" placeholder="Contact" value="{{old('contact',$lead->contact)}}"/>
                                                                @if($errors->has('contact'))
                                                                <span class="form-text">{{ $errors->first('contact') }}</span>
                                                                @endif
                                                            </div>
                                                        </div>
                                                        <!--end::Group-->
                                                        <!--begin::Group-->
                                                        <div class="form-group row">
                                                            <label class="col-xl-3 col-lg-3 col-form-label">Phone Number <span class="required">*</span></label>
                                                            <div class="col-lg-9 col-xl-9">
                                                                <input class="form-control form-control-solid form-control-lg" name="number" id="userNumber"  onkeypress="return numberPressed(event);" value="{{old('number',$lead->number)}}" placeholder="(123) 123 - 1234" type="text" />
                                                                @if($errors->has('number'))
                                                                <span class="form-text">{{ $errors->first('number') }}</span>
                                                                @endif
                                                            </div>
                                                        </div>
                                                        <!--end::Group-->
                                                        <!--begin::Group-->
                                                        <div class="form-group row">
                                                            <label class="col-xl-3 col-lg-3 col-form-label">Email Address<span class="required">*</span></label>
                                                            <div class="col-lg-9 col-xl-9">
                                                                <div class="input-group input-group-solid input-group-lg">
                                                                    <div class="input-group-prepend">
                                                                        <span class="input-group-text">
                                                                            <i class="la la-at"></i>
                                                                        </span>
                                                                    </div>
                                                                    <input type="text" class="form-control form-control-solid form-control-lg" name="email" placeholder="Email Address" value="{{old('email',$lead->email)}}"/>
                                                                    
                                                                </div>
                                                                @if($errors->has('email'))
                                                                    <span class="form-text">{{ $errors->first('email') }}</span>
                                                                    @endif
                                                                <!-- <span class="form-text text-muted">Enter valid US phone number(e.g: 5678967456).</span> -->
                                                            </div>
                                                        </div>
                                                        <!--end::Group-->
                                                        <!--begin::Group-->
                                                        <div class="form-group row">
                                                            <label class="col-xl-3 col-lg-3 col-form-label">Primary Address <span class="required">*</span></label>
                                                            <div class="col-lg-9 col-xl-9">
                                                                <div class="input-group input-group-solid input-group-lg">
                                                                    <div class="input-group-prepend">
                                                                        <span class="input-group-text">
                                                                            <i class="la la-home"></i>
                                                                        </span>
                                                                    </div>
                                                                    <input type="text" class="form-control form-control-solid form-control-lg" name="primary_address" placeholder="Primary Address" value="{{old('primary_address',$lead->primary_address)}}"/>
                                                                    
                                                                </div>
                                                                @if($errors->has('primary_address'))
                                                                  <span class="form-text">{{ $errors->first('primary_address') }}</span>
                                                                @endif
                                                            </div>
                                                        </div>
                                                        <!--end::Group-->
                                                        <!--begin::Group-->
                                                        <div class="form-group row">
                                                            <label class="col-xl-3 col-lg-3 col-form-label">Address Line 1 <span class="required">*</span></label>
                                                            <div class="col-lg-9 col-xl-9">
                                                                <div class="input-group input-group-solid input-group-lg">
                                                                    <input type="text" class="form-control form-control-solid form-control-lg" name="addressline1" placeholder="Address Line 1" value="{{old('addressline1',$lead->addressline1)}}"/>
                                                                    <div class="input-group-append">
                                                                        <span class="input-group-text">.</span>
                                                                    </div>
                                                                </div>
                                                                @if($errors->has('addressline1'))
                                                                <span class="form-text">{{ $errors->first('addressline1') }}</span>
                                                                @endif
                                                            </div>
                                                        </div>
                                                        <div class="form-group row">
                                                            <label class="col-xl-3 col-lg-3 col-form-label">Address Line 2</label>
                                                            <div class="col-lg-9 col-xl-9">
                                                                <div class="input-group input-group-solid input-group-lg">
                                                                    <input type="text" class="form-control form-control-solid form-control-lg" name="addressline2" placeholder="Address Line 2" value="{{old('addressline2',$lead->addressline2)}}"/>
                                                                    <div class="input-group-append">
                                                                        <span class="input-group-text">.</span>
                                                                    </div>
                                                                </div>
                                                                @if($errors->has('addressline2'))
                                                                <span class="form-text">{{ $errors->first('addressline2') }}</span>
                                                                @endif
                                                            </div>
                                                        </div>
                                                        <div class="form-group row">
                                                            <label class="col-xl-3 col-lg-3 col-form-label">City <span class="required">*</span></label>
                                                            <div class="col-lg-9 col-xl-9">
                                                                <div class="input-group input-group-solid input-group-lg">
                                                                    <input type="text" class="form-control form-control-solid form-control-lg"  name="city" placeholder="City" value="{{old('city',$lead->city)}}"/>
                                                                    <div class="input-group-append">
                                                                        <span class="input-group-text">.</span>
                                                                    </div>
                                                                </div>
                                                                @if($errors->has('city'))
                                                                <span class="form-text">{{ $errors->first('city') }}</span>
                                                                @endif
                                                            </div>
                                                        </div>
                                                        <div class="form-group row">
                                                            <label class="col-xl-3 col-lg-3 col-form-label">State <span class="required">*</span></label>
                                                            <div class="col-lg-9 col-xl-9">
                                                                <!-- <div class="input-group input-group-solid input-group-lg">
                                                                    <input type="text" class="form-control form-control-solid form-control-lg" required="" name="state" placeholder="State" />
                                                                </div> -->
                                                                <div class="dropdown bootstrap-select form-control">
                                                                    <select class="form-control selectpicker" name="state" data-size="4" tabindex="null">
                                                                        <option value="Alabama" @if (old('state',$lead->state) == "Alabama") {{ 'selected' }} @endif>Alabama</option>
                                                                        <option value="Alaska" @if (old('state',$lead->state) == "Alaska") {{ 'selected' }} @endif>Alaska</option>
                                                                        <option value="Arizona" @if (old('state',$lead->state) == "Arizona") {{ 'selected' }} @endif>Arizona</option>
                                                                        <option value="Arkansas" @if (old('state',$lead->state) == "Arkansas") {{ 'selected' }} @endif>Arkansas</option>
                                                                        <option value="California" @if (old('state',$lead->state) == "California") {{ 'selected' }} @endif>California</option>
                                                                        <option value="Colorado" @if (old('state',$lead->state) == "Colorado") {{ 'selected' }} @endif>Colorado</option>
                                                                        <option value="Connecticut" @if (old('state',$lead->state) == "Connecticut") {{ 'selected' }} @endif>Connecticut</option>
                                                                        <option value="Delaware" @if (old('state',$lead->state) == "Delaware") {{ 'selected' }} @endif>Delaware</option>
                                                                        <option value="Florida" @if (old('state',$lead->state) == "Florida") {{ 'selected' }} @endif>Florida</option>
                                                                        <option value="Georgia" @if (old('state',$lead->state) == "Georgia") {{ 'selected' }} @endif>Georgia</option>
                                                                        <option value="Hawaii" @if (old('state',$lead->state) == "Hawaii") {{ 'selected' }} @endif>Hawaii</option>
                                                                        <option value="Idaho" @if (old('state',$lead->state) == "Idaho") {{ 'selected' }} @endif>Idaho</option>
                                                                        <option value="Illinois" @if (old('state',$lead->state) == "Illinois") {{ 'selected' }} @endif>Illinois</option>
                                                                        <option value="Indiana" @if (old('state',$lead->state) == "Indiana") {{ 'selected' }} @endif>Indiana</option>
                                                                        <option value="Iowa" @if (old('state',$lead->state) == "Iowa") {{ 'selected' }} @endif>Iowa</option>
                                                                        <option value="Kansas" @if (old('state',$lead->state) == "Kansas") {{ 'selected' }} @endif>Kansas</option>
                                                                        <option value="Kentucky" @if (old('state',$lead->state) == "Kentucky") {{ 'selected' }} @endif>Kentucky</option>
                                                                        <option value="Louisiana" @if (old('state',$lead->state) == "Louisiana") {{ 'selected' }} @endif>Louisiana</option>
                                                                        <option value="Maine" @if (old('state',$lead->state) == "Maine") {{ 'selected' }} @endif>Maine</option>
                                                                        <option value="Maryland" @if (old('state',$lead->state) == "Maryland") {{ 'selected' }} @endif>Maryland</option>
                                                                        <option value="Massachusetts" @if (old('state',$lead->state) == "Massachusetts") {{ 'selected' }} @endif>Massachusetts</option>
                                                                        <option value="Michigan" @if (old('state',$lead->state) == "Michigan") {{ 'selected' }} @endif>Michigan</option>
                                                                        <option value="Minnesota" @if (old('state',$lead->state) == "Minnesota") {{ 'selected' }} @endif>Minnesota</option>
                                                                        <option value="Mississippi" @if (old('state',$lead->state) == "Mississippi") {{ 'selected' }} @endif>Mississippi</option>
                                                                        <option value="Missouri" @if (old('state',$lead->state) == "Missouri") {{ 'selected' }} @endif>Missouri</option>
                                                                        <option value="Montana" @if (old('state',$lead->state) == "Montana") {{ 'selected' }} @endif>Montana</option>
                                                                        <option value="Nebraska" @if (old('state',$lead->state) == "Nebraska") {{ 'selected' }} @endif>Nebraska</option>
                                                                        <option value="Nevada" @if (old('state',$lead->state) == "Nevada") {{ 'selected' }} @endif>Nevada</option>
                                                                        <option value="New Hampshire" @if (old('state',$lead->state) == "New Hampshire") {{ 'selected' }} @endif>New Hampshire</option>
                                                                        <option value="New Jersey" @if (old('state',$lead->state) == "New Jersey") {{ 'selected' }} @endif>New Jersey</option>
                                                                        <option value="New Mexico" @if (old('state',$lead->state) == "New Mexico") {{ 'selected' }} @endif>New Mexico</option>
                                                                        <option value="New York" @if (old('state',$lead->state) == "New York") {{ 'selected' }} @endif>New York</option>
                                                                        <option value="North Carolina" @if (old('state',$lead->state) == "North Carolina") {{ 'selected' }} @endif>North Carolina</option>
                                                                        <option value="North Dakota" @if (old('state',$lead->state) == "North Dakota") {{ 'selected' }} @endif>North Dakota</option>
                                                                        <option value="Ohio" @if (old('state',$lead->state) == "Ohio") {{ 'selected' }} @endif>Ohio</option>
                                                                        <option value="Oklahoma" @if (old('state',$lead->state) == "Oklahoma") {{ 'selected' }} @endif>Oklahoma</option>
                                                                        <option value="Oregon" @if (old('state',$lead->state) == "Oregon") {{ 'selected' }} @endif>Oregon</option>
                                                                        <option value="Pennsylvania" @if (old('state',$lead->state) == "Pennsylvania") {{ 'selected' }} @endif>Pennsylvania</option>
                                                                        <option value="Rhode Island" @if (old('state',$lead->state) == "Rhode Island") {{ 'selected' }} @endif>Rhode Island</option>
                                                                        <option value="South Carolina" @if (old('state',$lead->state) == "South Carolina") {{ 'selected' }} @endif>South Carolina</option>
                                                                        <option value="South Dakota" @if (old('state',$lead->state) == "South Dakota") {{ 'selected' }} @endif>South Dakota</option>
                                                                        <option value="Tennessee" @if (old('state',$lead->state) == "Tennessee") {{ 'selected' }} @endif>Tennessee</option>
                                                                        <option value="Texas" @if (old('state',$lead->state) == "Texas") {{ 'selected' }} @endif>Texas</option>
                                                                        <option value="Utah" @if (old('state',$lead->state) == "Utah") {{ 'selected' }} @endif>Utah</option>
                                                                        <option value="Vermont" @if (old('state',$lead->state) == "Vermont") {{ 'selected' }} @endif>Vermont</option>
                                                                        <option value="Virginia" @if (old('state',$lead->state) == "Virginia") {{ 'selected' }} @endif>Virginia</option>
                                                                        <option value="Washington" @if (old('state',$lead->state) == "Washington") {{ 'selected' }} @endif>Washington</option>
                                                                        <option value="West Virginia" @if (old('state',$lead->state) == "West Virginia") {{ 'selected' }} @endif>West Virginia</option>
                                                                        <option value="Wisconsin" @if (old('state',$lead->state) == "Wisconsin") {{ 'selected' }} @endif>Wisconsin</option>
                                                                        <option value="Wyoming" @if (old('state',$lead->state) == "Wyoming") {{ 'selected' }} @endif>Wyoming</option>
                                                                    </select>
                                                                </div>
                                                                @if($errors->has('state'))
                                                                <span class="form-text">{{ $errors->first('state') }}</span>
                                                                @endif
                                                            </div>
                                                        </div>
                                                        <div class="form-group row">
                                                            <label class="col-xl-3 col-lg-3 col-form-label">Zip Code <span class="required">*</span></label>
                                                            <div class="col-lg-9 col-xl-9">
                                                                <div class="input-group input-group-solid input-group-lg">
                                                                    <input type="text" class="form-control form-control-solid form-control-lg" name="zip_code" placeholder="Zip Code" maxlength="5" value="{{old('zip_code',$lead->zip_code)}}"/>
                                                                    <div class="input-group-append">
                                                                        <span class="input-group-text">.</span>
                                                                    </div>
                                                                </div>
                                                                @if($errors->has('zip_code'))
                                                                <span class="form-text">{{ $errors->first('zip_code') }}</span>
                                                                @endif
                                                            </div>
                                                        </div>
                                                        <!--end::Group-->
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="pull-right" style="float: right;">
                                                <input type="submit" class="btn btn-primary" value="submit">
                                            </div>
                                        </form>
                                        <!--end::Wizard Form-->
                                    </div>
                                </div>
                            </div>
                            <!--end::Body-->
                        </div>
                        <!--end::Card-->
                    </div>
                    <!--end::Wizard-->
                </div>
            </div>
            <!--end::Card-->
        </div>
        <!--end::Container-->
    </div>
    <!--end::Entry-->
</div>
<!--end::Content-->
@endsection

@section('bottom_links')

	<!-- phone number format -->
	<script>
		// Format the phone number as the user types it
		document.getElementById('phoneNumber').addEventListener('keyup', function(evt) {
			var phoneNumber = document.getElementById('phoneNumber');
			var charCode = (evt.which) ? evt.which : evt.keyCode;
			phoneNumber.value = phoneFormat(phoneNumber.value);
		});

		// We need to manually format the phone number on page load
		document.getElementById('phoneNumber').value = phoneFormat(document.getElementById('phoneNumber').value);

		// A function to determine if the pressed key is an integer
		function numberPressed(evt) {
			var charCode = (evt.which) ? evt.which : evt.keyCode;
			if (charCode > 31 && (charCode < 48 || charCode > 57) && (charCode < 36 || charCode > 40)) {
				return false;
			}
			return true;
		}

		// A function to format text to look like a phone number
		function phoneFormat(input) {
			// Strip all characters from the input except digits
			input = input.replace(/\D/g, '');

			// Trim the remaining input to ten characters, to preserve phone number format
			input = input.substring(0, 10);

			// Based upon the length of the string, we add formatting as necessary
			var size = input.length;
			if (size == 0) {
				input = input;
			} else if (size < 4) {
				input = '(' + input;
			} else if (size < 7) {
				input = '(' + input.substring(0, 3) + ') ' + input.substring(3, 6);
			} else {
				input = '(' + input.substring(0, 3) + ') ' + input.substring(3, 6) + ' - ' + input.substring(6, 10);
			}
			return input;
		}
	</script>
<!--begin::Page Vendors(used by this page)-->
<script src="{{asset('assets/plugins/custom/datatables/datatables.bundle.js')}}"></script>
<!--end::Page Vendors-->
<!--begin::Page Scripts(used by this page)-->
<script src="{{asset('assets/js/pages/features/datatables/basic/scrollable.js')}}"></script>

<script src="{{asset('assets/backend/js/pages/features/ktdatatable/base/html-table.js')}}"></script>
<!--end::Page Scripts-->
@endsection