@extends('admin.master')
@section("title")
<title>Gymitless | Reports</title>
@endsection
@section('content')
<div class="content d-flex flex-column flex-column-fluid" id="kt_content">
    <!--begin::Entry-->
    <div class="d-flex flex-column-fluid">
        <!--begin::Container-->
        <div class="container">
            <!--begin::Notice-->
            <div class="card card-custom gutter-b"></div>
            <!--end::Notice-->
            <!--begin::Card-->
            <div class="card card-custom gutter-b">
                <div class="card-header flex-wrap border-0 pt-6 pb-0">
                    <div class="card-title">
                        <h3 class="card-label">Reports Table
                            <!-- <span class="d-block text-muted pt-2 font-size-sm">scrollable datatable with fixed height</span> -->
                        </h3>
                    </div>
                    <div class="card-toolbar">
                        <!--begin::Dropdown-->
                        <div class="dropdown dropdown-inline mr-2">
                            <button type="button" class="btn btn-light-primary btn-pill font-weight-bolder dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <span class="svg-icon svg-icon-md">
                                    <!--begin::Svg Icon | path:assets/media/svg/icons/Design/PenAndRuller.svg-->
                                    <i class="flaticon-squares"></i>
                                    <!--end::Svg Icon-->
                                </span>Choose</button>
                            <!--begin::Dropdown Menu-->
                            <div class="dropdown-menu dropdown-menu-md dropdown-menu-right" style="">
                                <!--begin::Navigation-->
                                <ul class="navi flex-column navi-hover py-2">
                                    <li class="navi-header font-weight-bolder text-uppercase font-size-sm text-primary pb-2">Choose an option:</li>
                                    <li class="navi-item" id="click_new_customer">
                                        <a href="#" class="navi-link">
                                            <span class="navi-icon">
                                                <i class="la la-print"></i>
                                            </span>
                                            <span class="navi-text">New Customers Accounts</span>
                                        </a>
                                    </li>
                                    <li class="navi-item" id="click_closed_account">
                                        <a href="#" class="navi-link">
                                            <span class="navi-icon">
                                                <i class="la la-copy"></i>
                                            </span>
                                            <span class="navi-text">Closed Accounts</span>
                                        </a>
                                    </li>
                                    <li class="navi-item" id="click_new_location">
                                        <a href="#" class="navi-link">
                                            <span class="navi-icon">
                                                <i class="la la-file-excel-o"></i>
                                            </span>
                                            <span class="navi-text">New Locations</span>
                                        </a>
                                    </li>
                                    <li class="navi-item" id="click_ninty_day">
                                        <a href="#" class="navi-link">
                                            <span class="navi-icon">
                                                <i class="la la-file-text-o"></i>
                                            </span>
                                            <span class="navi-text">90 Day Outs</span>
                                        </a>
                                    </li>
                                </ul>
                                <!--end::Navigation-->
                            </div>
                            <!--end::Dropdown Menu-->
                        </div>
                        <!--end::Dropdown-->
                        <!--begin::Button-->
                        <!-- <a href="#" class="btn btn-primary font-weight-bolder">
                            <span class="svg-icon svg-icon-md">
                                <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="24px" height="24px" viewBox="0 0 24 24" version="1.1">
                                    <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                                        <rect x="0" y="0" width="24" height="24" />
                                        <circle fill="#000000" cx="9" cy="15" r="6" />
                                        <path d="M8.8012943,7.00241953 C9.83837775,5.20768121 11.7781543,4 14,4 C17.3137085,4 20,6.6862915 20,10 C20,12.2218457 18.7923188,14.1616223 16.9975805,15.1987057 C16.9991904,15.1326658 17,15.0664274 17,15 C17,10.581722 13.418278,7 9,7 C8.93357256,7 8.86733422,7.00080962 8.8012943,7.00241953 Z" fill="#000000" opacity="0.3" />
                                    </g>
                                </svg>
                            </span>New Record</a> -->
                        <!--end::Button-->
                    </div>
                </div>

                <!-- New Customers Accounts Table -->
                <div class="card-body" style="" id="new_customer">
                    <!--begin: Datatable-->
                    <h4><i class="flaticon2-next"></i> New Customers Accounts</h4>
                    <hr>
                    <div id="kt_datatable11_wrapper" class="dataTables_wrapper dt-bootstrap4 no-footer"><div class="dt-buttons btn-group flex-wrap">          <button class="btn btn-secondary buttons-copy buttons-html5" tabindex="0" aria-controls="kt_datatable11" type="button"><span>Copy</span></button> <button class="btn btn-secondary buttons-csv buttons-html5" tabindex="0" aria-controls="kt_datatable11" type="button"><span>CSV</span></button> <button class="btn btn-secondary buttons-excel buttons-html5" tabindex="0" aria-controls="kt_datatable11" type="button"><span>Excel</span></button> <button class="btn btn-secondary buttons-pdf buttons-html5" tabindex="0" aria-controls="kt_datatable11" type="button"><span>PDF</span></button> <button class="btn btn-secondary buttons-print" tabindex="0" aria-controls="kt_datatable11" type="button"><span>Print</span></button> </div><div id="kt_datatable11_filter" class="dataTables_filter"><label>Search:<input type="search" class="form-control form-control-sm" placeholder="" aria-controls="kt_datatable11"></label></div><table class="table table-separate table-head-custom table-checkable dataTable no-footer" id="kt_datatable11" role="grid" aria-describedby="kt_datatable11_info">
                        <thead>
                            <tr role="row"><th class="sorting_asc" tabindex="0" aria-controls="kt_datatable11" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Company Name: activate to sort column descending" style="width: 0px;">Company Name</th><th class="sorting" tabindex="0" aria-controls="kt_datatable11" rowspan="1" colspan="1" aria-label="Total Units: activate to sort column ascending" style="width: 0px;">Total Units</th><th class="sorting" tabindex="0" aria-controls="kt_datatable11" rowspan="1" colspan="1" aria-label="Account Manager: activate to sort column ascending" style="width: 0px;">Account Manager</th><th class="sorting" tabindex="0" aria-controls="kt_datatable11" rowspan="1" colspan="1" aria-label="Date Added: activate to sort column ascending" style="width: 0px;">Date Added</th><th class="sorting" tabindex="0" aria-controls="kt_datatable11" rowspan="1" colspan="1" aria-label="Status: activate to sort column ascending" style="width: 0px;">Status</th></tr>
                        </thead>
                        <tbody>
                                                    <tr class="odd"><td valign="top" colspan="5" class="dataTables_empty">No data available in table</td></tr></tbody>
                    </table><div class="dataTables_info" id="kt_datatable11_info" role="status" aria-live="polite">Showing 0 to 0 of 0 entries</div><div class="dataTables_paginate paging_simple_numbers" id="kt_datatable11_paginate"><ul class="pagination"><li class="paginate_button page-item previous disabled" id="kt_datatable11_previous"><a href="#" aria-controls="kt_datatable11" data-dt-idx="0" tabindex="0" class="page-link"><i class="ki ki-arrow-back"></i></a></li><li class="paginate_button page-item next disabled" id="kt_datatable11_next"><a href="#" aria-controls="kt_datatable11" data-dt-idx="1" tabindex="0" class="page-link"><i class="ki ki-arrow-next"></i></a></li></ul></div></div>
                    <!--end: Datatable-->
                </div>

                <!-- Closed Accounts Table -->
                <div class="card-body" style="display: none;" id="closed_account">
                    <!--begin: Datatable-->
                    <h4><i class="flaticon2-next"></i> Closed Accounts</h4>
                    <hr>
                    <div id="example_wrapper" class="dataTables_wrapper dt-bootstrap4 no-footer"><div class="dt-buttons btn-group flex-wrap">          <button class="btn btn-secondary buttons-copy buttons-html5" tabindex="0" aria-controls="example" type="button"><span>Copy</span></button> <button class="btn btn-secondary buttons-csv buttons-html5" tabindex="0" aria-controls="example" type="button"><span>CSV</span></button> <button class="btn btn-secondary buttons-excel buttons-html5" tabindex="0" aria-controls="example" type="button"><span>Excel</span></button> <button class="btn btn-secondary buttons-pdf buttons-html5" tabindex="0" aria-controls="example" type="button"><span>PDF</span></button> <button class="btn btn-secondary buttons-print" tabindex="0" aria-controls="example" type="button"><span>Print</span></button> </div><div id="example_filter" class="dataTables_filter"><label>Search:<input type="search" class="form-control form-control-sm" placeholder="" aria-controls="example"></label></div><table class="table table-separate table-head-custom table-checkable dataTable no-footer" id="example" role="grid" aria-describedby="example_info">
                        <thead>
                            <tr role="row"><th class="sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Company Name: activate to sort column descending" style="width: 0px;">Company Name</th><th class="sorting" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-label="Total Units: activate to sort column ascending" style="width: 0px;">Total Units</th><th class="sorting" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-label="Account Manager: activate to sort column ascending" style="width: 0px;">Account Manager</th><th class="sorting" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-label="Date Added: activate to sort column ascending" style="width: 0px;">Date Added</th><th class="sorting" tabindex="0" aria-controls="example" rowspan="1" colspan="1" aria-label="Status: activate to sort column ascending" style="width: 0px;">Status</th></tr>
                        </thead>
                        <tbody>
                                                    <tr class="odd"><td valign="top" colspan="5" class="dataTables_empty">No data available in table</td></tr></tbody>
                    </table><div class="dataTables_info" id="example_info" role="status" aria-live="polite">Showing 0 to 0 of 0 entries</div><div class="dataTables_paginate paging_simple_numbers" id="example_paginate"><ul class="pagination"><li class="paginate_button page-item previous disabled" id="example_previous"><a href="#" aria-controls="example" data-dt-idx="0" tabindex="0" class="page-link"><i class="ki ki-arrow-back"></i></a></li><li class="paginate_button page-item next disabled" id="example_next"><a href="#" aria-controls="example" data-dt-idx="1" tabindex="0" class="page-link"><i class="ki ki-arrow-next"></i></a></li></ul></div></div>
                    <!--end: Datatable-->
                </div>

                <!-- New Locations Table -->
                <div class="card-body" style="display: none;" id="new_location">
                    <!--begin: Datatable-->
                    <h4><i class="flaticon2-next"></i> New Locations</h4>
                    <hr>
                    <div id="kt_datatable12_wrapper" class="dataTables_wrapper dt-bootstrap4 no-footer"><div class="dt-buttons btn-group flex-wrap">          <button class="btn btn-secondary buttons-copy buttons-html5" tabindex="0" aria-controls="kt_datatable12" type="button"><span>Copy</span></button> <button class="btn btn-secondary buttons-csv buttons-html5" tabindex="0" aria-controls="kt_datatable12" type="button"><span>CSV</span></button> <button class="btn btn-secondary buttons-excel buttons-html5" tabindex="0" aria-controls="kt_datatable12" type="button"><span>Excel</span></button> <button class="btn btn-secondary buttons-pdf buttons-html5" tabindex="0" aria-controls="kt_datatable12" type="button"><span>PDF</span></button> <button class="btn btn-secondary buttons-print" tabindex="0" aria-controls="kt_datatable12" type="button"><span>Print</span></button> </div><div id="kt_datatable12_filter" class="dataTables_filter"><label>Search:<input type="search" class="form-control form-control-sm" placeholder="" aria-controls="kt_datatable12"></label></div><table class="table table-separate table-head-custom table-checkable dataTable no-footer" id="kt_datatable12" role="grid" aria-describedby="kt_datatable12_info">
                        <thead>
                            <tr role="row"><th class="sorting_asc" tabindex="0" aria-controls="kt_datatable12" rowspan="1" colspan="1" aria-sort="ascending" aria-label="Company Name: activate to sort column descending" style="width: 0px;">Company Name</th><th class="sorting" tabindex="0" aria-controls="kt_datatable12" rowspan="1" colspan="1" aria-label="Gym Location: activate to sort column ascending" style="width: 0px;">Gym Location</th><th class="sorting" tabindex="0" aria-controls="kt_datatable12" rowspan="1" colspan="1" aria-label="Account Manager: activate to sort column ascending" style="width: 0px;">Account Manager</th><th class="sorting" tabindex="0" aria-controls="kt_datatable12" rowspan="1" colspan="1" aria-label="Date Added: activate to sort column ascending" style="width: 0px;">Date Added</th><th class="sorting" tabindex="0" aria-controls="kt_datatable12" rowspan="1" colspan="1" aria-label="Status: activate to sort column ascending" style="width: 0px;">Status</th></tr>
                        </thead>
                        <tbody>
                                                    <tr class="odd"><td valign="top" colspan="5" class="dataTables_empty">No data available in table</td></tr></tbody>
                    </table><div class="dataTables_info" id="kt_datatable12_info" role="status" aria-live="polite">Showing 0 to 0 of 0 entries</div><div class="dataTables_paginate paging_simple_numbers" id="kt_datatable12_paginate"><ul class="pagination"><li class="paginate_button page-item previous disabled" id="kt_datatable12_previous"><a href="#" aria-controls="kt_datatable12" data-dt-idx="0" tabindex="0" class="page-link"><i class="ki ki-arrow-back"></i></a></li><li class="paginate_button page-item next disabled" id="kt_datatable12_next"><a href="#" aria-controls="kt_datatable12" data-dt-idx="1" tabindex="0" class="page-link"><i class="ki ki-arrow-next"></i></a></li></ul></div></div>
                    <!--end: Datatable-->
                </div>

                <!-- 90 Day Outs Table -->
                <div class="card-body" style="display:none;" id="ninty_day">
                    <!--begin: Datatable-->
                    <h4><i class="flaticon2-next"></i> 90 Day Outs</h4>
                    <hr>
                    <table class="table table-separate table-head-custom table-checkable" id="kt_datatable13">
                        <thead>
                            <tr>
                                <th>Company Name</th>
                                <th>Total Units</th>
                                <th>Account Manager</th>
                                <th>Date Added</th>
                                <th>Date Closed</th>
                                <th>Status</th>
                                <!-- <th>Actions</th> -->
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>Aroma Travels</td>
                                <td>1 Unit</td>
                                <td>Ammar Mark</td>
                                <td>12-05-2020</td>
                                <td>23-06-2020</td>
                                <td><span class="label label-lg font-weight-bold label-light-danger label-inline">Rejected</span></td>
                                <!-- <td><a href="javascript:;" class="btn btn-sm btn-clean btn-icon mr-2" title="Edit Lead">
                                        <span class="svg-icon svg-icon-md">
                                            <i class="flaticon2-edit"></i>
                                        </span>
                                    </a>
                                    <a href="javascript:;" class="btn btn-sm btn-clean btn-icon" title="Delete">
                                        <span class="svg-icon svg-icon-md">
                                            <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="24px" height="24px" viewBox="0 0 24 24" version="1.1">
                                                <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                                                    <rect x="0" y="0" width="24" height="24" />
                                                    <path d="M6,8 L6,20.5 C6,21.3284271 6.67157288,22 7.5,22 L16.5,22 C17.3284271,22 18,21.3284271 18,20.5 L18,8 L6,8 Z" fill="#000000" fill-rule="nonzero" />
                                                    <path d="M14,4.5 L14,4 C14,3.44771525 13.5522847,3 13,3 L11,3 C10.4477153,3 10,3.44771525 10,4 L10,4.5 L5.5,4.5 C5.22385763,4.5 5,4.72385763 5,5 L5,5.5 C5,5.77614237 5.22385763,6 5.5,6 L18.5,6 C18.7761424,6 19,5.77614237 19,5.5 L19,5 C19,4.72385763 18.7761424,4.5 18.5,4.5 L14,4.5 Z" fill="#000000" opacity="0.3" />
                                                </g>
                                            </svg>
                                        </span>
                                    </a>
                                </td> -->
                            </tr>
                        </tbody>
                    </table>
                    <!--end: Datatable-->
                </div>
                
            </div>
            <!--end::Card-->
        </div>
        <!--end::Container-->
    </div>
    <!--end::Entry-->
</div>
@endsection
